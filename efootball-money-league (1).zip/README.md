# eFOOTBALL MONEY LEAGUE
Static site (HTML/JS) + Supabase. Public page: `/`. Admin: `/admin`. No server code, no secret keys.

## Setup
1. Create a project at supabase.com. SQL Editor → paste and run `schema.sql`.
2. Authentication → Providers → Email: **turn OFF "Allow new users to sign up"**. Authentication → Users → **Add user** (your email + strong password, auto-confirm).
3. Make that user the admin (SQL Editor): `insert into admins(user_id) select id from auth.users where email='YOU@EMAIL.COM';`
4. Project Settings → API: copy Project URL and the **anon** key into `config.js`. Never use the `service_role` key.
5. Deploy: push this folder to GitHub → Vercel → New Project → Deploy (no build settings). Or `npx vercel --prod`.

## Using it
Admin → Players (add 32, assign groups or Random draw) → Matches → Group stage → Generate → enter scores/dates →
Publishing → publish each section. After groups finish: Matches → Round of 16 → Generate, then QF, SF, Third place, Final.
Draws in knockouts need penalty scores. Declare the champion in Champion, then publish it.

## Rules and security
- Ranking: points, goal difference, goals scored, head-to-head, then admin tiebreak number (Players tab).
- Row Level Security enforces publishing: hidden matches, groups, standings, champion and announcements cannot be read by the public via the site, direct API calls or realtime. Only users in `admins` can write.
- Publishing fixtures, standings or knockouts also makes player names readable, and group fixtures inherently show groups.
- Regenerating a stage does not touch later stages; regenerate those too.
