const sb = supabase.createClient(CFG.url, CFG.key);
const $ = s => document.querySelector(s);
const E = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const G = 'ABCDEFGH'.split('');
// ranking: points, goal difference, goals scored, head-to-head, admin decision
const sortS = a => [...a].sort((x,y) => y.points-x.points || y.goal_diff-x.goal_diff || y.goals_for-x.goals_for ||
  y.h2h-x.h2h || x.manual_rank-y.manual_rank || x.name.localeCompare(y.name));
const tbl = r => '<div style="overflow-x:auto"><table><tr><th>#</th><th>Player</th><th>P</th><th>W</th><th>D</th><th>L</th><th>GF</th><th>GA</th><th>GD</th><th>Pts</th></tr>' +
  sortS(r).map((x,i) => `<tr class="${i<2?'q':''}"><td>${i+1}</td><td>${E(x.name)}</td><td>${x.played}</td><td>${x.won}</td><td>${x.drawn}</td><td>${x.lost}</td><td>${x.goals_for}</td><td>${x.goals_against}</td><td>${x.goal_diff}</td><td><b>${x.points}</b></td></tr>`).join('') + '</table></div>';
const fmt = d => d ? new Date(d).toLocaleString([], {dateStyle:'medium', timeStyle:'short'}) : 'Date to be announced';
const card = (m, P) => `<div class="card"><div class="muted">${m.group_name ? 'Group '+m.group_name+' · ' : ''}${fmt(m.kickoff)}</div>
<div class="mt"><b>${E(P[m.home_id]?.name || 'TBD')}</b><span class="sc">${m.status==='done' ? m.home_score+' - '+m.away_score : 'vs'}</span><b>${E(P[m.away_id]?.name || 'TBD')}</b></div>
${m.home_pen != null ? `<div class="muted" style="text-align:center">Penalties ${m.home_pen} - ${m.away_pen}</div>` : ''}</div>`;
const live = f => { let t; sb.channel('live').on('postgres_changes', {event:'*', schema:'public'}, () => { clearTimeout(t); t = setTimeout(f, 300); }).subscribe(); };
