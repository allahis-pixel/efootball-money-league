const KO = [['r16','Round of 16'],['qf','Quarter-finals'],['sf','Semi-finals'],['third','Third-place playoff'],['final','Grand Final']];
const lock = t => `<div class="lock">🔒 ${t} will appear here once published.</div>`;
async function load() {
  const [f,p,m,s,a,c] = await Promise.all([
    sb.from('publish_flags').select('*'), sb.from('players').select('*'),
    sb.from('matches').select('*').order('slot'), sb.from('group_standings').select('*'),
    sb.from('announcements').select('*').order('created_at', {ascending:false}),
    sb.from('champion').select('*').maybeSingle()]);
  $('#err').hidden = !f.error; if (f.error) $('#err').textContent = 'Could not load tournament data. Please refresh shortly.';
  const F = Object.fromEntries((f.data||[]).map(x => [x.key, x.published]));
  const P = Object.fromEntries((p.data||[]).map(x => [x.id, x]));
  const M = m.data||[], S = s.data||[], pl = Object.values(P).filter(x => x.group_name);
  $('#groups-body').innerHTML = F.standings && S.length
    ? '<div class="grid">' + G.map(g => `<div class="card"><h3>Group ${g}</h3>${tbl(S.filter(x => x.group_name===g))}</div>`).join('') + '</div><p class="muted">Highlighted rows qualify for the Round of 16.</p>'
    : F.groups && pl.length
    ? '<div class="grid">' + G.map(g => `<div class="card"><h3>Group ${g}</h3>${pl.filter(x => x.group_name===g).map(x => `<div>${E(x.name)}</div>`).join('')}</div>`).join('') + '</div>'
    : lock('Groups and standings');
  const gm = M.filter(x => x.stage==='group');
  $('#fix-body').innerHTML = F.fixtures && gm.length
    ? G.map(g => { const ms = gm.filter(x => x.group_name===g); return ms.length ? `<h3>Group ${g}</h3><div class="grid">${ms.map(x => card(x,P)).join('')}</div>` : ''; }).join('')
    : lock('Fixtures');
  $('#ko-body').innerHTML = KO.map(([k,t]) => { const ms = M.filter(x => x.stage===k);
    return `<h3>${t}</h3>` + (F[k] && ms.length ? `<div class="grid">${ms.map(x => card(x,P)).join('')}</div>` : lock(t)); }).join('');
  const ch = c.data && F.champion ? P[c.data.player_id] : null;
  $('#champ-body').innerHTML = ch ? `<div class="card" style="text-align:center"><div class="trophy">🏆</div><h1>${E(ch.name)}</h1><p>eFOOTBALL MONEY LEAGUE CHAMPION</p></div>` : lock('The champion');
  $('#news-body').innerHTML = (a.data||[]).map(x => `<div class="card"><h3>${E(x.title)}</h3><div class="muted">${fmt(x.created_at)}</div><pre class="ann" style="text-align:left">${E(x.body)}</pre></div>`).join('') || '<div class="lock">No announcements yet.</div>';
}
load(); live(load);
