// Supabase > Project Settings > API. The anon key is PUBLIC by design; data is protected by RLS in schema.sql.
// NEVER put the service_role key here.
window.CFG = { url: 'YOUR_SUPABASE_URL', key: 'YOUR_SUPABASE_ANON_KEY' };
