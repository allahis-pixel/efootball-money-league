-- eFOOTBALL MONEY LEAGUE — run this whole file in Supabase > SQL Editor
create extension if not exists pgcrypto;

create table admins (user_id uuid primary key references auth.users on delete cascade);
create table players (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  group_name text check (group_name in ('A','B','C','D','E','F','G','H')),
  manual_rank int not null default 99,           -- admin tiebreak decision (lower = higher)
  created_at timestamptz default now());
create table matches (
  id uuid primary key default gen_random_uuid(),
  stage text not null check (stage in ('group','r16','qf','sf','third','final')),
  group_name text,
  slot int not null default 1,
  home_id uuid references players on delete cascade,
  away_id uuid references players on delete cascade,
  home_score int check (home_score >= 0), away_score int check (away_score >= 0),
  home_pen int, away_pen int,
  kickoff timestamptz,
  status text not null default 'scheduled' check (status in ('scheduled','done')));
create table publish_flags (key text primary key, published boolean not null default false);
create table champion (id int primary key check (id = 1), player_id uuid references players on delete set null);
create table announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null, body text not null default '',
  published boolean not null default true, created_at timestamptz default now());

insert into publish_flags(key) values ('groups'),('fixtures'),('standings'),('r16'),('qf'),('sf'),('third'),('final'),('champion');

create function is_admin() returns boolean language sql security definer stable set search_path = public
  as $$ select exists (select 1 from admins where user_id = auth.uid()) $$;
create function is_pub(k text) returns boolean language sql security definer stable set search_path = public
  as $$ select coalesce((select published from publish_flags where key = k), false) $$;

alter table admins enable row level security;
alter table players enable row level security;
alter table matches enable row level security;
alter table publish_flags enable row level security;
alter table champion enable row level security;
alter table announcements enable row level security;

create policy "own row" on admins for select using (user_id = auth.uid());
create policy "read flags" on publish_flags for select using (true);
create policy "admin flags" on publish_flags for all using (is_admin()) with check (is_admin());
create policy "read players" on players for select using (is_admin() or is_pub('groups') or is_pub('fixtures')
  or is_pub('standings') or is_pub('r16') or is_pub('qf') or is_pub('sf') or is_pub('third') or is_pub('final') or is_pub('champion'));
create policy "admin players" on players for all using (is_admin()) with check (is_admin());
create policy "read matches" on matches for select using (is_admin()
  or (stage = 'group' and is_pub('fixtures')) or (stage <> 'group' and is_pub(stage)));
create policy "admin matches" on matches for all using (is_admin()) with check (is_admin());
create policy "read champion" on champion for select using (is_admin() or is_pub('champion'));
create policy "admin champion" on champion for all using (is_admin()) with check (is_admin());
create policy "read announcements" on announcements for select using (is_admin() or published);
create policy "admin announcements" on announcements for all using (is_admin()) with check (is_admin());

-- Standings are calculated in the database. Ranking order (applied by the apps):
-- points, goal difference, goals scored, head-to-head points, admin decision (players.manual_rank).
-- Runs with owner rights but only returns rows when standings are published (or caller is admin).
create view group_standings as
with r as (
  select home_id p, away_id o, home_score gf, away_score ga from matches where stage='group' and status='done'
  union all
  select away_id, home_id, away_score, home_score from matches where stage='group' and status='done'),
s as (
  select p, count(*) played, count(*) filter (where gf>ga) won, count(*) filter (where gf=ga) drawn,
         count(*) filter (where gf<ga) lost, sum(gf) goals_for, sum(ga) goals_against, sum(gf)-sum(ga) goal_diff,
         3*count(*) filter (where gf>ga) + count(*) filter (where gf=ga) points
  from r group by p)
select pl.id player_id, pl.name, pl.group_name, pl.manual_rank,
  coalesce(s.played,0)::int played, coalesce(s.won,0)::int won, coalesce(s.drawn,0)::int drawn, coalesce(s.lost,0)::int lost,
  coalesce(s.goals_for,0)::int goals_for, coalesce(s.goals_against,0)::int goals_against,
  coalesce(s.goal_diff,0)::int goal_diff, coalesce(s.points,0)::int points,
  (select coalesce(sum(case when x.gf>x.ga then 3 when x.gf=x.ga then 1 else 0 end),0)::int
     from r x join s t on t.p = x.o
     where x.p = pl.id and t.points = s.points and t.goal_diff = s.goal_diff and t.goals_for = s.goals_for) h2h
from players pl left join s on s.p = pl.id
where pl.group_name is not null and (is_admin() or is_pub('standings'));
grant select on group_standings to anon, authenticated;

alter publication supabase_realtime add table matches, players, publish_flags, announcements, champion;
