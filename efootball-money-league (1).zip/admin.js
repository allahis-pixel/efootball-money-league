let P=[], M=[], S=[], F={}, A=[], C=null, tab='players', stg='group';
const KEYS=[['groups','Group assignments'],['fixtures','Group fixtures'],['standings','Group standings'],['r16','Round of 16'],['qf','Quarter-finals'],['sf','Semi-finals'],['third','Third-place playoff'],['final','Grand Final'],['champion','Champion announcement']];
const SN={group:'Group stage',r16:'Round of 16',qf:'Quarter-finals',sf:'Semi-finals',third:'Third-place playoff',final:'Grand Final'};
const loc=d=>d?new Date(new Date(d)-new Date(d).getTimezoneOffset()*6e4).toISOString().slice(0,16):'';
const W=m=>{if(m.status!=='done')return null;let h=m.home_score,a=m.away_score;if(h===a){h=m.home_pen;a=m.away_pen}if(h==null||a==null||h===a)return null;return h>a?m.home_id:m.away_id};
const L=m=>{const w=W(m);return w?(w===m.home_id?m.away_id:m.home_id):null};
const run=async q=>{const {error}=await q;if(error)alert(error.message);else await reload()};

function showLogin(msg){$('#app').innerHTML=`<div class="card" style="max-width:380px;margin:60px auto"><h2>Admin login</h2><p class="on-t off-t">${E(msg||'')}</p>
<div class="row"><input id="em" type="email" placeholder="Email" autocomplete="username" style="width:100%"></div>
<div class="row"><input id="pw" type="password" placeholder="Password" autocomplete="current-password" style="width:100%" onkeydown="if(event.key==='Enter')login()"></div>
<button onclick="login()">Sign in</button></div>`}
async function login(){const {error}=await sb.auth.signInWithPassword({email:$('#em').value,password:$('#pw').value});if(error)return showLogin(error.message);init()}
async function init(){const {data:{session}}=await sb.auth.getSession();if(!session)return showLogin();
  const {data}=await sb.from('admins').select('user_id').maybeSingle();
  if(!data){await sb.auth.signOut();return showLogin('This account is not an administrator.')}await reload()}
async function reload(){const r=await Promise.all([sb.from('players').select('*').order('name'),sb.from('matches').select('*').order('slot'),sb.from('group_standings').select('*'),sb.from('publish_flags').select('*'),sb.from('announcements').select('*').order('created_at',{ascending:false}),sb.from('champion').select('*').maybeSingle()]);
  P=r[0].data||[];M=r[1].data||[];S=r[2].data||[];F=Object.fromEntries((r[3].data||[]).map(x=>[x.key,x.published]));A=r[4].data||[];C=r[5].data;render()}
const go=(t,s)=>{tab=t;if(s)stg=s;render()};

function render(){
  const T=[['players','Players'],['matches','Matches'],['publish','Publishing'],['news','Announcements'],['champ','Champion']];
  const PM=Object.fromEntries(P.map(p=>[p.id,p])),nm=id=>E(PM[id]?.name||'TBD');
  let h=`<nav style="position:static;border-radius:14px">${T.map(([k,t])=>`<button class="${tab===k?'on':''}" onclick="go('${k}')">${t}</button>`).join('')}<button onclick="sb.auth.signOut().then(init)">Log out</button></nav><section>`;
  if(tab==='players'){
    h+=`<h2>Players (${P.length}/32)</h2><div class="row"><input id="np" placeholder="Player name"><button onclick="addP()">Add player</button><button class="o" onclick="draw()">Random draw into groups</button></div>
    <p class="muted">Tiebreak = admin decision when everything else is equal (lower number ranks higher). After changing groups, regenerate group fixtures.</p>`+
    P.map(p=>`<div class="row"><input id="n${p.id}" value="${E(p.name)}"><select id="g${p.id}"><option value="">No group</option>${G.map(g=>`<option ${p.group_name===g?'selected':''}>${g}</option>`).join('')}</select><input class="s" id="r${p.id}" type="number" value="${p.manual_rank}" title="Tiebreak"><button onclick="saveP('${p.id}')">Save</button><button class="d" onclick="delP('${p.id}')">Remove</button></div>`).join('');
  }
  if(tab==='matches'){
    const ko=stg!=='group',ms=M.filter(m=>m.stage===stg).sort((a,b)=>(a.group_name||'').localeCompare(b.group_name||'')||a.slot-b.slot);
    h+=`<div class="row">${Object.entries(SN).map(([k,t])=>`<button class="${stg===k?'':'o'}" onclick="go('matches','${k}')">${t}</button>`).join('')}</div>
    <div class="row"><button onclick="gen('${stg}')">${M.some(m=>m.stage===stg)?'Regenerate':'Generate'} ${SN[stg]} fixtures</button></div>
    <div class="grid">${ms.map(m=>`<div class="card" id="m${m.id}"><div class="muted">${m.group_name?'Group '+m.group_name+' · ':''}Match ${m.slot}</div>
    <div class="mt"><b>${nm(m.home_id)}</b><span><input class="s" name="hs" type="number" min="0" value="${m.home_score??''}"> : <input class="s" name="as" type="number" min="0" value="${m.away_score??''}"></span><b>${nm(m.away_id)}</b></div>
    ${ko?`<div class="row" style="justify-content:center">Penalties <input class="s" name="hp" type="number" min="0" value="${m.home_pen??''}"> : <input class="s" name="ap" type="number" min="0" value="${m.away_pen??''}"></div>`:''}
    <div class="row"><input type="datetime-local" name="k" value="${loc(m.kickoff)}"><button onclick="saveM('${m.id}')">Save</button></div></div>`).join('')||'<div class="lock">No matches yet.</div>'}</div>`;
    if(stg==='group'&&S.length)h+='<h3>Live standings</h3><div class="grid">'+G.map(g=>`<div class="card"><b>Group ${g}</b>${tbl(S.filter(x=>x.group_name===g))}</div>`).join('')+'</div>';
  }
  if(tab==='publish')h+=`<h2>Publishing</h2><p class="muted">Hidden items are blocked at the database level for public visitors.</p>`+KEYS.map(([k,t])=>`<div class="row card"><b style="flex:1">${t}</b><span class="${F[k]?'on-t':'off-t'}">${F[k]?'Published':'Hidden'}</span><button class="${F[k]?'o':''}" onclick="flag('${k}',${!F[k]})">${F[k]?'Hide':'Publish'}</button></div>`).join('');
  if(tab==='news')h+=`<h2>Announcements</h2><div class="card"><div class="row"><input id="at" placeholder="Title" style="width:100%"></div><div class="row"><textarea id="ab" rows="4" placeholder="Message" style="width:100%"></textarea></div><button onclick="addA()">Publish announcement</button></div>`+
    A.map(a=>`<div class="card" style="margin-top:10px"><b>${E(a.title)}</b> <span class="${a.published?'on-t':'off-t'}">${a.published?'Published':'Hidden'}</span><pre class="ann" style="text-align:left">${E(a.body)}</pre><div class="row"><button class="o" onclick="run(sb.from('announcements').update({published:${!a.published}}).eq('id','${a.id}'))">${a.published?'Hide':'Publish'}</button><button class="d" onclick="confirm('Delete?')&&run(sb.from('announcements').delete().eq('id','${a.id}'))">Delete</button></div></div>`).join('');
  if(tab==='champ')h+=`<h2>Champion</h2><div class="row"><select id="cp"><option value="">Choose player</option>${P.map(p=>`<option value="${p.id}" ${C?.player_id===p.id?'selected':''}>${E(p.name)}</option>`).join('')}</select><button onclick="setC()">Declare champion</button></div>
    <div class="row">Public status: <b class="${F.champion?'on-t':'off-t'}">${F.champion?'Published':'Hidden'}</b><button onclick="flag('champion',${!F.champion})">${F.champion?'Hide champion':'Publish champion'}</button></div>`;
  $('#app').innerHTML=h+'</section>';
}
const addP=()=>{const n=$('#np').value.trim();if(n)run(sb.from('players').insert({name:n}))};
const saveP=id=>run(sb.from('players').update({name:$('#n'+id).value.trim(),group_name:$('#g'+id).value||null,manual_rank:+$('#r'+id).value||99}).eq('id',id));
const delP=id=>confirm('Remove this player and their matches?')&&run(sb.from('players').delete().eq('id',id));
async function draw(){if(P.length!==32&&!confirm('There are '+P.length+' players, not 32. Draw anyway?'))return;
  const s=[...P].sort(()=>Math.random()-.5);const rs=await Promise.all(s.map((p,i)=>sb.from('players').update({group_name:G[Math.floor(i/4)]||null}).eq('id',p.id)));
  const e=rs.find(r=>r.error);if(e)alert(e.error.message);await reload()}
const flag=(k,v)=>run(sb.from('publish_flags').upsert({key:k,published:v}));
const addA=()=>{const t=$('#at').value.trim();if(t)run(sb.from('announcements').insert({title:t,body:$('#ab').value,published:true}))};
const setC=()=>$('#cp').value?run(sb.from('champion').upsert({id:1,player_id:$('#cp').value})):alert('Choose a player first.');
async function saveM(id){const r=$('#m'+id),m=M.find(x=>x.id===id);
  const v=n=>{const e=r.querySelector('[name='+n+']');return !e||e.value===''?null:+e.value};
  const hs=v('hs'),as=v('as'),hp=v('hp'),ap=v('ap'),k=r.querySelector('[name=k]').value,done=hs!=null&&as!=null;
  if(done&&m.stage!=='group'&&hs===as&&(hp==null||ap==null||hp===ap))return alert('Knockout draw: enter penalty scores with a winner.');
  run(sb.from('matches').update({home_score:hs,away_score:as,home_pen:hs===as?hp:null,away_pen:hs===as?ap:null,kickoff:k?new Date(k).toISOString():null,status:done?'done':'scheduled'}).eq('id',id))}
async function gen(stage){
  const ex=M.filter(m=>m.stage===stage);
  if(ex.length&&!confirm('This replaces existing '+SN[stage]+' matches and their scores. Continue?'))return;
  const rows=[];
  if(stage==='group'){for(const g of G){const pl=P.filter(p=>p.group_name===g);if(pl.length!==4)return alert('Group '+g+' needs exactly 4 players (has '+pl.length+').');
    [[0,1],[2,3],[0,2],[1,3],[0,3],[1,2]].forEach(([a,b],i)=>rows.push({stage,group_name:g,slot:i+1,home_id:pl[a].id,away_id:pl[b].id}))}}
  else if(stage==='r16'){for(const g of G)if(S.filter(x=>x.group_name===g&&x.played===3).length!==4)return alert('Group '+g+' is not finished yet.');
    const r=g=>sortS(S.filter(x=>x.group_name===g));
    [['A','B'],['C','D'],['E','F'],['G','H'],['B','A'],['D','C'],['F','E'],['H','G']].forEach(([a,b],i)=>rows.push({stage,slot:i+1,home_id:r(a)[0].player_id,away_id:r(b)[1].player_id}))}
  else{const src={qf:'r16',sf:'qf',third:'sf',final:'sf'}[stage],pm=M.filter(m=>m.stage===src).sort((a,b)=>a.slot-b.slot);
    if(pm.length!=={qf:8,sf:4,third:2,final:2}[stage])return alert('Generate '+SN[src]+' first.');
    const w=pm.map(W),l=pm.map(L);if((stage==='third'?l:w).includes(null))return alert('Every '+SN[src]+' match needs a decided result first.');
    if(stage==='third')rows.push({stage,slot:1,home_id:l[0],away_id:l[1]});
    else if(stage==='final')rows.push({stage,slot:1,home_id:w[0],away_id:w[1]});
    else for(let i=0;i<w.length;i+=2)rows.push({stage,slot:i/2+1,home_id:w[i],away_id:w[i+1]})}
  if(ex.length){const d=await sb.from('matches').delete().eq('stage',stage);if(d.error)return alert(d.error.message)}
  run(sb.from('matches').insert(rows))}
init();
